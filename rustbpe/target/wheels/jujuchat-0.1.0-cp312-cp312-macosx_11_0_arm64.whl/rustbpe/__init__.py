from .rustbpe import *

__doc__ = rustbpe.__doc__
if hasattr(rustbpe, "__all__"):
    __all__ = rustbpe.__all__